package com.zezzi.navigationcompose.ui.events.model

data class Event(
    var name: String,
    val availableSeats: Int,
)